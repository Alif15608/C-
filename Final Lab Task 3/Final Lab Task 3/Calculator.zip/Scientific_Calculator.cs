﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Lab_Task_3
{
    interface Scientific_Calculator
    {
        int XtoY(int x, int y);
        int square(int x);
        int factorial(int x);
    }
}
